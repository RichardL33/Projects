document.write("<script type='text/javascript' charset='utf-8' src='./resources/_jim/javascript/jim-min.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scenarios/function-jim-links1515208958019.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/_jim/javascript/mobile/ios/ios8/iphone/jim-iphone-min.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scroll-1515208958019.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/prototype-1515208958019.js'></script>");