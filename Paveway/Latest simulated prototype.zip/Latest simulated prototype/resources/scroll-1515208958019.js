(function(window, undefined) {

    /*********************** START STATIC ACCESS METHODS ************************/

    jQuery.extend(jimMobile, {
        "loadScrollBars": function() {
            jQuery(".s-14920cf7-5007-49d7-99a8-b366ddc4e4c0 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-b8320871-3798-46e0-8255-ec4a0785610d .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-b8320871-3798-46e0-8255-ec4a0785610d #s-Category_1").overscroll({ showThumbs:false, direction:'vertical' });
            jQuery(".s-f46885c3-90ed-4442-bec7-1f08c17885df .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-28f769b0-bf9c-45ad-9fd1-1136b6969257 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-6a19cb1d-8e4d-4271-be3f-459d00bbde17 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-ce3c1935-93b5-4f0e-b55c-865199db12e3 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-0bc9c163-5ed2-4be0-857c-9dfe33d59dae .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-f5b4367b-80b2-4c75-943d-b07fbc8d6e05 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-58a4bece-0001-4fdc-92d1-4d1b581b06ff .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-58213289-3b86-4477-9579-ae075049a40c .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-d12245cc-1680-458d-89dd-4f0d7fb22724 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-04068873-23af-43bc-9215-4ec84b14a832 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-4d8fca04-8b11-46f6-9aca-d6690c7cc8a1 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-09469008-8480-4b21-90db-67a4e50654d6 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-5d774a9e-43dd-4a9b-9ad7-b60d8795f887 .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
            jQuery(".s-0f49bb14-cc76-4390-b591-73c78b82783f .ui-page").overscroll({ showThumbs:true, direction:'vertical' });
         }
    });

    /*********************** END STATIC ACCESS METHODS ************************/

}) (window);