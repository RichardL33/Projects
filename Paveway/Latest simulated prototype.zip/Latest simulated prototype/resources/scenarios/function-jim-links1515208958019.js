(function(window, undefined) {

  var jimLinks = {
    "14920cf7-5007-49d7-99a8-b366ddc4e4c0" : {
      "Button_1" : [
        "5d774a9e-43dd-4a9b-9ad7-b60d8795f887"
      ],
      "Button_10" : [
        "0f49bb14-cc76-4390-b591-73c78b82783f"
      ]
    },
    "b8320871-3798-46e0-8255-ec4a0785610d" : {
      "Button-blue" : [
        "04068873-23af-43bc-9215-4ec84b14a832"
      ]
    },
    "f46885c3-90ed-4442-bec7-1f08c17885df" : {
      "Button-black_1" : [
        "09469008-8480-4b21-90db-67a4e50654d6"
      ]
    },
    "58a4bece-0001-4fdc-92d1-4d1b581b06ff" : {
      "Button_2" : [
        "ce3c1935-93b5-4f0e-b55c-865199db12e3"
      ],
      "Button_3" : [
        "f5b4367b-80b2-4c75-943d-b07fbc8d6e05"
      ],
      "Button_4" : [
        "0bc9c163-5ed2-4be0-857c-9dfe33d59dae"
      ],
      "Button-blue" : [
        "0f49bb14-cc76-4390-b591-73c78b82783f"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Panel_6" : [
        "04068873-23af-43bc-9215-4ec84b14a832"
      ],
      "Button_7" : [
        "58a4bece-0001-4fdc-92d1-4d1b581b06ff",
        "58a4bece-0001-4fdc-92d1-4d1b581b06ff"
      ]
    },
    "04068873-23af-43bc-9215-4ec84b14a832" : {
      "Button_1" : [
        "09469008-8480-4b21-90db-67a4e50654d6"
      ],
      "Button_2" : [
        "0bc9c163-5ed2-4be0-857c-9dfe33d59dae"
      ],
      "Button_3" : [
        "0f49bb14-cc76-4390-b591-73c78b82783f"
      ],
      "Button_4" : [
        "14920cf7-5007-49d7-99a8-b366ddc4e4c0"
      ],
      "Button_5" : [
        "6a19cb1d-8e4d-4271-be3f-459d00bbde17"
      ],
      "Button_6" : [
        "b8320871-3798-46e0-8255-ec4a0785610d"
      ]
    },
    "4d8fca04-8b11-46f6-9aca-d6690c7cc8a1" : {
      "Label_28" : [
        "09469008-8480-4b21-90db-67a4e50654d6",
        "09469008-8480-4b21-90db-67a4e50654d6"
      ],
      "Label_29" : [
        "09469008-8480-4b21-90db-67a4e50654d6"
      ]
    },
    "09469008-8480-4b21-90db-67a4e50654d6" : {
      "Button-red" : [
        "4d8fca04-8b11-46f6-9aca-d6690c7cc8a1"
      ],
      "Menu_item_47" : [
        "f46885c3-90ed-4442-bec7-1f08c17885df"
      ],
      "Menu_item_48" : [
        "f46885c3-90ed-4442-bec7-1f08c17885df"
      ],
      "Menu_item_49" : [
        "f46885c3-90ed-4442-bec7-1f08c17885df"
      ],
      "Menu_item_50" : [
        "f46885c3-90ed-4442-bec7-1f08c17885df"
      ],
      "Menu_item_51" : [
        "f46885c3-90ed-4442-bec7-1f08c17885df"
      ],
      "Menu_item_52" : [
        "f46885c3-90ed-4442-bec7-1f08c17885df"
      ],
      "Menu_item_53" : [
        "f46885c3-90ed-4442-bec7-1f08c17885df"
      ]
    },
    "5d774a9e-43dd-4a9b-9ad7-b60d8795f887" : {
      "Button_1" : [
        "09469008-8480-4b21-90db-67a4e50654d6"
      ],
      "Button_2" : [
        "f5b4367b-80b2-4c75-943d-b07fbc8d6e05"
      ],
      "Button_3" : [
        "0f49bb14-cc76-4390-b591-73c78b82783f"
      ],
      "Button_4" : [
        "14920cf7-5007-49d7-99a8-b366ddc4e4c0"
      ],
      "Button_5" : [
        "6a19cb1d-8e4d-4271-be3f-459d00bbde17"
      ],
      "Button_6" : [
        "58213289-3b86-4477-9579-ae075049a40c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);